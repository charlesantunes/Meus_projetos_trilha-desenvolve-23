const notas = [10 ,6 ,8] // 7
notas.push()
console.log(notas)

let media = (notas[0] + notas[1] + notas[2] + notas[3])/notas.length

console.log(media)