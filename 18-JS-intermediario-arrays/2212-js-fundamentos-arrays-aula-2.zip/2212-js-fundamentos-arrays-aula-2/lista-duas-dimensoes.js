              //0
const alunos = ['João', 'Juliana', 'Caio', 'Ana']

                      //0
const mediasDosAlunos = [10,7,9,6]

// let listaDeAlunos = [['João', 'Juliana', 'Caio', 'Ana'], [10,7,9,6]]
                          //0       //1
let listaDeNotasEAlunos = [alunos, mediasDosAlunos]

console.log(`${listaDeNotasEAlunos[0][0]}, sua media é ${listaDeNotasEAlunos[1][0]}`)